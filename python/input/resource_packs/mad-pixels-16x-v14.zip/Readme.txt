Thanks for downloading the Mad Pixels resource pack!
MadPixels By VeryMadCrafter@Planetminecraft.com
-----------
How to install:
1.Download the Mad Pixels resource pack
2.Run Minecraft
3.Click "Resource Packs"
4.Click "Open Res.Pack folder"
5.Put the Mad Pixels.zip in there
6.Select it,and play!
Strongly recommended: Turn on Fancy textures! Download MC Patcher to see additional features.
-----------
You are not allowed to use my textures without my permission.
You are allowed to make videos with my resource pack. You don`t need to ask my permission, but It`d be cool if you notify me about that.
-----------
Follow the newest versions of the Mad Pixels Pack at PlanetMinecraft.com!
If you like the pack, please support me by giving the pack a diamond at Planet Minecraft!
-----------
Support
Mad Pixels merch store: https://teespring.com/stores/mad-pixels-store
In the store, you can buy t-shirts, hoodies and other types of clothes that are based on the Mad Pixels painting art. 
Patreon: https://www.patreon.com/verymadcrafter
Your support is greatly appreciated and motivates me to update the pack. Thanks.


